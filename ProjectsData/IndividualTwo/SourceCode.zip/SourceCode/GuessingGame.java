import java.util.Scanner;
import java.util.Random;
import java.util.Date;
import java.time.*;
import java.io.PrintWriter;
import java.io.File;
import java.io.FileNotFoundException;
import static java.time.temporal.ChronoUnit.*;
import java.text.SimpleDateFormat;

class GuessingGame {
  public static void main(String[] args) throws FileNotFoundException {
    Random rand = new Random();
    File file = new File("scores.txt");
    Scanner scan = new Scanner(System.in);
    String name;
    Scanner reader = new Scanner(file);
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy");
    boolean play = true;
    int i = 0;
    String line;
    String[] highScore = {"","","",""};
    line = reader.nextLine();
    highScore = line.split(",");
    System.out.println("\nWelcome to the Guessing Game!");
    System.out.println("Guess a number between 1 and 100");
    System.out.println("\nFastest Time");
    System.out.println("Name: " + highScore[0]);
    System.out.println("Date: " + highScore[1]);
    System.out.println("Time: " + highScore[2] + " seconds");
    System.out.println("Number of Guesses: " + highScore[3]);
    System.out.print("\nWhat is your name: ");
    name = scan.nextLine();
    reader.close();
    while (play) {
      System.out.println("\nGame Started");
      LocalTime startTime = LocalTime.now();
      int randNum = rand.nextInt(100);
      int guess = 0;
      int attempts = 0;
      System.out.print("Guess: ");
      guess = scan.nextInt();
      while(guess != randNum){
        if(randNum>guess){
          System.out.println("Your guess was too low, try again!");
          System.out.print("Guess: ");
          guess = scan.nextInt();
        }else if(randNum<guess){
          System.out.println("Your guess was too high, try again!");
          System.out.print("Guess: ");
          guess = scan.nextInt();
        }
        attempts++;
      }
      LocalTime endTime = LocalTime.now();
      double time = MILLIS.between(startTime,endTime);
      time = time/1000;
      String date = simpleDateFormat.format(new Date());
      double recordTime = Double.parseDouble(highScore[2]);
      if (time < recordTime) {
        PrintWriter printer = new PrintWriter(file);
        printer.printf(name + ",");
        printer.printf(date + ",");
        printer.printf(time + ",");
        printer.printf(attempts + " ");
        printer.close();
      }
      System.out.println("You win!");
      System.out.println("\nWould you like to play again? [Y/N]: ");
      String ans = scan.next();
      if (ans.equals("Y") || ans.equals("y")) {
        play = true;
      } else if (ans.equals("N") || ans.equals("n")) {
        play = false;
        scan.close();
      } else {
        System.out.println("Did not recognize answer.");
        play = false;
        scan.close();
      }
    }
  }
}
