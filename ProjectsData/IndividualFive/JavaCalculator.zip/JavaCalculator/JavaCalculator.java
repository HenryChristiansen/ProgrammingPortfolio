import java.util.Scanner;
class JavaCalculator {
  public static void main(String[] args) {
    boolean userGoing;
    while ( userGoing = true) {
      System.out.println("\nWelcome to the Calculator");
      Scanner Scan = new Scanner(System.in);
      System.out.println("\nPlease Enter First Number:");
      float x1;
      float x2;
      float result;
      x1 = Scan.nextInt();
      System.out.println("\nPlease Enter Second Number:");
      x2 = Scan.nextInt();
      System.out.println("\n(+,-,*,/) Please type an operation, type it as seen in paretheses.");
      String operator = Scan.next();
      switch (operator) {
        default:
          System.out.println("Please enter a valid operator.");
        case "+":
          result = x1 + x2;
          System.out.println(x1 + operator + x2 + "=" + result);
          break;
        case "-":
          result = x1 - x2;
          System.out.println(x1 + operator + x2 + "=" + result);
          break;
        case "*":
          result = x1 * x2;
          System.out.println(x1 + operator + x2 + "=" + result);
          break;
        case "/":
          result = x1 / x2;
          System.out.println(x1 + operator + x2 + "=" + result);
          break;
      }
      System.out.println("\n Would you like to do another calculation (Yes/No)");
      String answer = Scan.next();
      switch (answer) {
        default:
          System.out.println("Try Again, invalid answer.");
        case "No":
          userGoing = false;
          Scan.close();
          break;
        case "Yes":
          userGoing = true;
          break;
      }
    }
  }
}
